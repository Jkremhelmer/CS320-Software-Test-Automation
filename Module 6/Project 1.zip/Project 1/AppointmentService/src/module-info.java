/**
 * 
 */
/**
 * 
 */
module AppointmentService {
	requires org.junit.jupiter.api;
}